
var sList = window.localStorage.getItem("students");
if (sList!=null){
var list= sList.split("$");
for (i=0;i<list.length;i++){
  var text = document.createTextNode(list[i])
  var p = document.createElement("p");
  var br = document.createElement("br")
  p.appendChild(text);
  var container=document.getElementById('studentList');
  container.appendChild(p);
  container.appendChild(br);
}
}
