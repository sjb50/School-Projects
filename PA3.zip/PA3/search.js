var sList = window.localStorage.getItem("students");
if (sList!=null){
var list = sList.split("$");
}
var p;
var container=document.getElementById('searchResults');

function search(){
  if (p!=null){
    container.removeChild(p);
  }
  found = false;
  var tester;
  var searchValue = document.getElementById('searchValue').value;
  if (sList!=null){
  for (count=0;count<list.length;count++){
    tester=list[count].split(" ");
    if (tester[2]==searchValue){
      var text = document.createTextNode(list[count]);
      p = document.createElement("p");
      p.appendChild(text);
      container.appendChild(p);
      found=true;
    }
  }
}
  if (found==false){
    var notFoundText = document.createTextNode("Student Not Found");
    p = document.createElement("p");
    p.appendChild(notFoundText);
    container.appendChild(p);
  }
}
