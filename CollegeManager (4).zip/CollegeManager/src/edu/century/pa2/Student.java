package edu.century.pa2;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import edu.century.Collections.CourseCollection;

public class Student implements Cloneable {
	private static int studentCounter = 0;
	private String studentId;
	private String firstName;
	private String lastName;
	private GregorianCalendar birthday;
	private String email;
	private CourseCollection courses;

	/**
	 * Students():a default constructor for a new student.
	 * 
	 */
	Student() {
		firstName = "";
		lastName = "";
		birthday = new GregorianCalendar(2000, 01, 01);
		email = "defaultStudent@my.century.edu";
		studentCounter = +10;
		studentId = firstName.substring(0, 1) + lastName.substring(0, 1) + "10" + studentCounter;
		courses = new CourseCollection();
	}

	/**
	 * @param fullName  the students name
	 * @param birthDate the students date of birth
	 */
	Student(String fullName, GregorianCalendar birthDate) {
		String[] full = fullName.split(" ");
		firstName = full[0];
		lastName = full[1];
		birthday = birthDate;
		email = firstName + "." + lastName + "@pa2.com";
		studentCounter = +10;
		studentId = firstName.substring(0, 2).toUpperCase() + birthday.get(Calendar.YEAR)
				+ lastName.substring(lastName.length() - 2).toUpperCase();
		courses = new CourseCollection();
	}

	/**
	 *@Specifications: returns the course of a student
	 *@Param:
	 *@Precondition:
	 *@Postcondition:  courses of a student returned
	 *@Exceptions:
	 *@Throws:
	 */
	public CourseCollection getCourses() {
		return courses;
	}

	/**
	 * @Specifications: returns the students id
	 * @Param: none
	 * @Precondition: none
	 * @Postcondition: returns the students id
	 * @Exceptions: none
	 * @Throws: none
	 */
	public String getStudentId() {
		return studentId;
	}

	/**
	 * @Specifications:sets the students id.
	 * @Param: String studentId
	 * @Precondition: none
	 * @Postcondition: changes the student's id
	 * @Exceptions:
	 * @Throws:
	 */
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	/**
	 * @Specifications:returns the students first name
	 * @Param:
	 * @Precondition:
	 * @Postcondition: returns the students id
	 * @Exceptions:
	 * @Throws:
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @Specifications: sets the students first name
	 * @Param:String firstName
	 * @Precondition:
	 * @Postcondition: changes the students firstName
	 * @Exceptions:
	 * @Throws:
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @Specifications: returns the students last name
	 * @Param:
	 * @Precondition:
	 * @Postcondition: returns the last name of the student
	 * @Exceptions:
	 * @Throws:
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @Specifications: sets the students lastName
	 * @Param: String lastName
	 * @Precondition: none
	 * @Postcondition: changes the students last name.
	 * @Exceptions:
	 * @Throws:
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @Specifications:gets the students date of birth
	 * @Param:
	 * @Precondition:
	 * @Postcondition: returns the students date of birth
	 * @Exceptions:
	 * @Throws:
	 */
	public GregorianCalendar getBirthday() {
		return birthday;
	}

	/**
	 * @Specifications: changes the students date of birth
	 * @Param:GregorianCalendar
	 * @Precondition:
	 * @Postcondition: changes the students date of birth
	 * @Exceptions:
	 * @Throws:
	 */
	public void setBirthday(GregorianCalendar birthday) {
		this.birthday = birthday;
	}

	/**
	 * @Specifications: gets the students email.
	 * @Param
	 * @Precondition:
	 * @Postcondition: returns the students email.
	 * @Exceptions:
	 * @Throws:
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @Specifications:sets the students email
	 * @Param:String email
	 * @Precondition:
	 * @Postcondition: changes the email.
	 * @Exceptions:
	 * @Throws:
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {

		String info = ("__________________\nfirstName: " + firstName + "\nlastName: " + lastName + "\nstudentId: "
				+ studentId + "\nbirthday: " + birthday.get(Calendar.MONTH) + "/" + birthday.get(Calendar.DAY_OF_MONTH)
				+ "/" + birthday.get(Calendar.YEAR) + "\nemail: " + email + "\n" + courses + "__________________\n\n");
		return info;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (birthday == null) {
			if (other.birthday != null)
				return false;
		} else if (!birthday.equals(other.birthday))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (studentId == null) {
			if (other.studentId != null)
				return false;
		} else if (!studentId.equals(other.studentId))
			return false;
		return true;
	}

	/**
	 *@Specifications: Clones student object
	 *@Param:
	 *@Precondition:
	 *@Postcondition: creates and returns a copy
	 *@Exceptions: if clone is not a student.
	 *@Throws: CloneNotSupportedException
	 */
	public Student clone(Student student) throws CloneNotSupportedException {
		if (student == null)
			throw new CloneNotSupportedException();
		if (!(student instanceof Student)) {
			throw new CloneNotSupportedException();
		} else {
			Student copy = (Student) student;
			return copy;
		}
	}
}
