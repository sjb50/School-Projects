package edu.century.pa2;

import java.util.GregorianCalendar;

import edu.century.Collections.StudentCollection;

public class TestDriver {
	public static void main(String[] args) {

		Student sam = new Student("sam bedell", new GregorianCalendar(1993, 3, 2));
		Student mitch = new Student("mitch miller", new GregorianCalendar(1993, 3, 2));
		Course math = new Course(0, "math", 0, 0, 0, "becker", "true");
		Course science = new Course(0, "scie", 0, 0, 0, "loere", "fsle");
		Course poly = new Course(0, "poly", 0, 0, 0, "becker", "true");
		Course gym = new Course(0, "gym", 0, 0, 0, "loere", "fsle");

		StudentCollection collection = new StudentCollection(1);
		collection.addMany(sam,mitch);
		
		sam.getCourses().addMany(math,poly,gym,science);
		mitch.getCourses().add(poly);
		
		sam.getCourses().searchByName("poly");
		System.out.print(collection);
	}
}
