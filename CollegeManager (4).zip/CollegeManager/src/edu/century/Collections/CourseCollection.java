package edu.century.Collections;

import edu.century.pa2.Course;
import edu.century.pa2.CourseNode;
import edu.century.pa2.Student;

public class CourseCollection {
	CourseNode head;
	CourseNode tail;

	public CourseCollection() {
		head = null;
		tail = null;
	}

	CourseCollection(Course course) {
		CourseNode startCourse = new CourseNode(course);
		head = startCourse;
		tail = head;
	}

	/**
	 * @Specifications:adds a course to the collection
	 * @Param: Course course;
	 * @Precondition:course cannot be null
	 * @Postcondition: course will be added to the collection
	 * @Exceptions:course cannot be null.
	 * @Throws: NullPointerException.
	 */
	public void add(Course course) {
		CourseNode newCourse = new CourseNode(course);
		if (head == (null)) {
			head = newCourse;
			tail = head;
		} else {
			tail.setLink(newCourse);
			tail = (tail.getLink());
		}
	}

	/**
	 * @Specifications: searches for a course by name
	 * @Param: String courseName
	 * @Precondition: none
	 * @Postcondition: returns true or false and prints off info
	 * @Exceptions:
	 * @Throws:
	 */
	public boolean searchByName(String courseName) {
		for (CourseNode cursor = this.head; cursor != null; cursor = cursor.getLink()) {
			if (cursor.getData().getSubject() == courseName) {
				System.out.println(cursor.getData());
				return true;
			}
		}
		System.out.println("Course not found");
		return false;
	}

	/**
	 * @Specifications: searches for a course by name
	 * @Param: String courseName
	 * @Precondition: none
	 * @Postcondition: returns true or false and prints off info
	 * @Exceptions:
	 * @Throws:
	 */
	public boolean searchById(int id) {
		for (CourseNode cursor = this.head; cursor != null; cursor = cursor.getLink()) {
			if (cursor.getData().getId() == id) {
				System.out.println(cursor.getData());
				return true;
			}
		}
		System.out.println("Course not found");
		return false;
	}

	/**
	 * @Specifications: Adds many courses to the collection.
	 * @Param: Courses...courses.
	 * @Precondition:courses cant be null.
	 * @Postcondition: courses will be added to the collection.
	 * @Exceptions:
	 * @Throws:NullPointerException.
	 */
	public void addMany(Course... courses) {
		for (int count = 0; count < courses.length; count++) {
			this.add(courses[count]);
		}
	}

	/**
	 * @Specifications: removes a course from the collection.
	 * @Param: course.
	 * @Precondition: course(argument) must not be null
	 * @Postcondition: course will be removed.
	 * @Exceptions: none
	 * @Throws:none
	 */
	public boolean remove(Course course) {
		for (CourseNode precursor = null, cursor = head; cursor != null; precursor = cursor, cursor = cursor
				.getLink()) {
			if (course.equals(cursor.getData())) {
				if (cursor.equals(head)) {
					head = cursor.getLink();
					return true;
				} else {
					precursor.setLink(cursor.getLink());
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public String toString() {
		String courseList = "";
		CourseNode cursor;
		for (cursor = head; cursor != null; cursor = cursor.getLink()) {
			courseList += cursor.getData();
		}
		return courseList;
	}
}
