package edu.century.Collections;

import java.util.Arrays;

import edu.century.pa2.Student;

public class StudentCollection {
	Student[] students;

	/*
	 * @Specs: default constructor that starts the array with a value of 10
	 */
	public StudentCollection() {
		students = new Student[10];
	}

	public StudentCollection(int size) {
		students = new Student[size];
	}

	/**
	 * @Specifications:adds a student to the collection
	 * @Param:Student student
	 * @Precondition:Collection must not be null
	 * @Postcondition:student is added to the collection
	 * @Exceptions:
	 * @Throws:NullPointerException
	 */
	public void addStudent(Student newStudent) {
		for (int count = 0; count < students.length + 1; count++) {
			if (count == students.length) {
				this.increaseCapacity();
			}
			if (students[count] == null) {
				students[count] = newStudent;
				return;
			}
		}
	}

	/**
	 * @Specifications: increases the capacity of the students array
	 * @Param:Student[] students
	 * @Precondition:
	 * @Postcondition:
	 * @Exceptions:
	 * @Throws:
	 */
	public void increaseCapacity() {
		Student[] biggerList = new Student[students.length * 2 + 1];
		for (int count = 0; count < students.length; count++) {
			biggerList[count] = students[count];
		}
		students = biggerList;
	}

	/**
	 * @Specifications:removes the student if student is found in the collect.
	 * @Param: Student student.
	 * @Precondition:
	 * @Postcondition: student will be removed.
	 * @Exceptions: if students is null
	 * @Throws:NullPointerException
	 */
	public boolean remove(Student student) {
		for (int count = 0; count < students.length; count++) {
			if (student.equals(students[count])) {
				students[count] = null;
				System.out.println("student Removed");
				return true;
			}
		}
		System.out.println("student not found.");
		return false;
	}

	/**
	 * @Specifications:adds an array of students
	 * @Param:Student[] manyStudents
	 * @Precondition:
	 * @Postcondition: x amount of students added to the array.
	 * @Exceptions:
	 * @Throws:
	 */
	public void addMany(Student... manyStudents) {
		for (int count = 0; count < manyStudents.length; count++) {
			this.addStudent(manyStudents[count]);
		}
	}

	/**
	 * @Specifications: gets capacity of an array
	 * @Param:
	 * @Precondition:
	 * @Postcondition:returns the total
	 * @Exceptions:
	 * @Throws:
	 */
	public int getCapacity() {
		return students.length;
	}

	/**
	 * @Specifications:Gets the amount of stored elements
	 * @Param:array
	 * @Precondition:
	 * @Postcondition: return itemCounter
	 * @Exceptions:
	 * @Throws:
	 */
	public int manyItems() {
		int itemCounter = 0;
		for (int count = 0; count < students.length; count++) {
			if (students[count] != null) {
				itemCounter++;
			}
		}

		return itemCounter;
	}

	/**
	 * @Specifications: will join the two StudentCollection objects into one
	 * @Param:Collection1 Collection2
	 * @Precondition:
	 * @Postcondition:Two collection will be joined into 1
	 * @Exceptions:
	 * @Throws:
	 */
	public static StudentCollection union(StudentCollection collection1, StudentCollection collection2) {
		StudentCollection newCollection = new StudentCollection(collection1.getCapacity() + collection2.getCapacity());
		System.arraycopy(collection1.students, 0, newCollection.students, 0, collection1.getCapacity());
		System.arraycopy(collection2.students, 0, newCollection.students, collection1.manyItems(),
				collection2.manyItems());
		return newCollection;
	}

	/**
	 * @Specifications: searches the collection,based on last name
	 * @Param: String lastName
	 * @Precondition:
	 * @Postcondition: returns true or false and displays information
	 * @Exceptions:
	 * @Throws:
	 */
	public boolean searchByLastName(String lastName) {
		for (int count = 0; count < students.length; count++) {
			if (students[count] != null) {
				if (lastName.equals(students[count].getLastName())) {
					System.out.print(students[count]);
					return true;
				}
			}
		}
		System.out.println("student not found");
		return false;
	}

	/**
	 *@Specifications:makes the size of the array equal to the current number of elements stored
	 *@Param: none
	 *@Precondition: 
	 *@Postcondition: array length is changed
	 *@Exceptions:
	 *@Throws:
	 */
	public void trimToSize() {
		Student[] trim;
		if (students.length != this.manyItems()) {
			trim = new Student[this.manyItems()];
			System.arraycopy(students, 0, trim, 0, this.manyItems());
			students = trim;
		}
	}

	/**
	 * @Specifications: Searches for a student by id.
	 * @Param: String id
	 * @Precondition:
	 * @Postcondition:
	 * @Exceptions:
	 * @Throws:
	 */
	public boolean searchById(String id) {
		for (int count = 0; count < students.length; count++) {
			if (students[count] != null) {
				if (id.equals(students[count].getStudentId())) {
					System.out.print(students[count]);
					return true;
				}
			}
		}
		System.out.println("student not found");
		return false;
	}

	@Override
	public String toString() {
		String list = "";
		for (int count = 0; count < students.length; count++) {
			if (students[count] != null) {
				list += students[count];
			}
		}
		return list;
	}
}
