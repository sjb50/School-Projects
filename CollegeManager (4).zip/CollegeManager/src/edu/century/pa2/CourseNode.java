package edu.century.pa2;

public class CourseNode {
	protected Course data;
	protected CourseNode link;

	/**
	 * Specifications: this constructor sets up a course node for the
	 * CourseCollection class
	 * 
	 * @param course the first course used to set up the node;
	 */
	public CourseNode(Course course) {
		data = course;
		link = null;
	}

	/**
	 * @Specifications:returns the data for the course
	 * @Param: none.
	 * @Precondition: none
	 * @Postcondition: returns data
	 * @Exceptions: none
	 * @Throws: none
	 */
	public Course getData() {
		return data;
	}

	/**
	 * @Specifications:sets the data for a course
	 * @Param: Course data
	 * @Precondition: argument cannot be null
	 * @Postcondition: data is changed to the argument
	 * @Exceptions: data(argument) cannot be null
	 * @Throws: NullPointerExecption
	 */
	public void setData(Course data) {
		this.data = data;
	}

	/**
	 * @Specifications: Returns the link of data
	 * @Param: none
	 * @Precondition: none
	 * @Postcondition: returns link
	 * @Exceptions: none
	 * @Throws: none
	 */
	public CourseNode getLink() {
		return link;
	}

	/**
	 * @Specifications: sets the link of the data
	 * @Param: Course link-changed the data's link
	 * @Precondition: link(argument) cannot be null
	 * @Postcondition: changes the data's link;
	 * @Exception:
	 * @Throws:NullPointerException
	 */
	public void setLink(CourseNode link) {
		this.link = link;
	}
}
