package edu.century.pa2;

public class Course implements Cloneable {
	private int id;
	private String subject;
	private int credits;
	private int courseNumber;
	private int courseSection;
	private String status;
	private String instructor;

	/**
	 * @param id-sets            course id
	 * @param subject-sets       the subject
	 * @param credits-sets       the courses credits.
	 * @param courseNumber-sets  the course number
	 * @param courseSection-sets the course section.
	 * @param status-sets        the course status
	 * @param instructor-sets    the course instructor
	 */
	Course(int id, String subject, int credits, int courseNumber, int courseSection, String status, String instructor) {
		this.id = id;
		this.subject = subject;
		this.credits = credits;
		this.courseNumber = courseNumber;
		this.courseSection = courseSection;
		this.status = status;
		this.instructor = instructor;
	}

	/**
	 * @Specifications: This method will return the id of the course
	 * @Param: none
	 * @Precondition: none
	 * @Postcondition:returns course's id
	 * @Exceptions:none
	 * @Throws:none
	 */
	public int getId() {
		return id;
	}

	/**
	 * @Specifications: sets the course id
	 * @Param:Int id-the number of the course id
	 * @Precondition: none
	 * @Postcondition: id is changed
	 * @Exceptions: none
	 * @Throws: none
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @Specifications: sets the subject of the course
	 * @Param: none
	 * @Precondition: none
	 * @Postcondition:returns the subject
	 * @Exceptions: none
	 * @Throws: none
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @Specifications: sets the subject of a course.
	 * @Param:String subject-the name of new course.
	 * @Precondition: none.
	 * @Postcondition:course subject is changed
	 * @Exceptions: none
	 * @Throws: none
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @Specifications: this will return the number a credits a course is worth.
	 * @Param: none
	 * @Precondition: none
	 * @Postcondition: returns credits
	 * @Exceptions: none
	 * @Throws: none
	 */
	public int getCredits() {
		return credits;
	}

	/**
	 * @Specifications: Sets the number of credits of a course.
	 * @Param: int credits-credits will be worth this much.
	 * @Precondition:none
	 * @Postcondition: credits will be changed.
	 * @Exceptions: none
	 * @Throws: none
	 */
	public void setCredits(int credits) {
		this.credits = credits;
	}

	/**
	 * @Specifications: returns the course's number.
	 * @Param: none
	 * @Precondition: none
	 * @Postcondition: returns the course number
	 * @Exceptions: none
	 * @Throws: none
	 */
	public int getCourseNumber() {
		return courseNumber;
	}

	/**
	 * @Specifications: sets the course number of a class
	 * @Param: int courseNumber-the new course number
	 * @Precondition: none
	 * @Postcondition: course number will be changed
	 * @Exceptions: none
	 * @Throws:none
	 */
	public void setCourseNumber(int courseNumber) {
		this.courseNumber = courseNumber;
	}

	/**
	 * @Specifications: will return the course section.
	 * @Param: none
	 * @Precondition: none
	 * @Postcondition: returns courseSection
	 * @Exceptions:none
	 * @Throws:none
	 */
	public int getCourseSection() {
		return courseSection;
	}

	/**
	 * @Specifications: sets the course's section
	 * @Param: int courseSection
	 * @Precondition: none
	 * @Postcondition: courseSection will be changed
	 * @Exceptions:none
	 * @Throws:none
	 */
	public void setCourseSection(int courseSection) {
		this.courseSection = courseSection;
	}

	/**
	 * @Specifications: gets the status of the class
	 * @Param: none
	 * @Precondition: none
	 * @Postcondition:returns status.
	 * @Exceptions:none
	 * @Throws:none
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @Specifications: Sets the status of the class.
	 * @Param:String status
	 * @Precondition:none
	 * @Postcondition: changes the course status to the string thats passed.
	 * @Exceptions:none
	 * @Throws:none
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @Specifications: will return the course's instructor.
	 * @Param: none
	 * @Precondition: none
	 * @Postcondition: returns instructor.
	 * @Exceptions: none
	 * @Throws:none
	 */
	public String getInstructor() {
		return instructor;
	}

	/**
	 * @Specifications:sets the course's instructor to the argument passes.
	 * @Param: String instructor
	 * @Precondition: none
	 * @Postcondition: instructor will be changed to the string passes.
	 * @Exceptions:none
	 * @Throws:none
	 */
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

	@Override
	public String toString() {
		return "-----Course-----\nid:" + id + "\nsubject:" + subject + "\ncredits:" + credits + "\nNumber:"
				+ courseNumber + "\nSection:" + courseSection + "\nstatus:" + status + "\ninstructor:" + instructor
				+ "\n----------------\n";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		if (courseNumber != other.courseNumber)
			return false;
		if (courseSection != other.courseSection)
			return false;
		if (credits != other.credits)
			return false;
		if (id != other.id)
			return false;
		if (instructor == null) {
			if (other.instructor != null)
				return false;
		} else if (!instructor.equals(other.instructor))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (subject == null) {
			if (other.subject != null)
				return false;
		} else if (!subject.equals(other.subject))
			return false;
		return true;
	}

	/**
	 * @Specifications: clones the course
	 * @Param: Object course
	 * @Precondition: object must not be null.
	 * @Postcondition: clones the course
	 * @Exceptions: if clone is not a Course object
	 * @Throws: CloneNotSupported Exception
	 */
	public static Course Clone(Object course) throws Exception {
		if (course == null)
			throw new CloneNotSupportedException();
		if (!(course instanceof Course)) {
			throw new CloneNotSupportedException();
		} else {
			Course copy = (Course) course;
			return copy;
		}
	}
}
