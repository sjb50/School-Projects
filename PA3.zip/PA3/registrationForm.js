
var students=window.localStorage.getItem("students");
console.log("this is Slist="+students);
if (students!=null){
  students=students.toString();
}
else {
  var students="";
}

var clearButton = document.getElementById('clearButton');
clearButton.onclick=clearForm;
var clearButton = document.getElementById('addButton');
clearButton.onclick=add;

function clearForm(){
  var nodeList=document.getElementsByClassName('inputWig');
  for (i=0;i<nodeList.length;i++)
    nodeList[i].value="";
  }

function setBackground(item){
  if (item.type=="focus"){
    item.target.style.backgroundColor="lightyellow";
  }
  else if (item.type=="blur"){
      item.target.style.backgroundColor="white";
  }
}

window.addEventListener("load",function(){
  var selector = "input[type=text]";
  var fields = document.querySelectorAll(selector);
  for (i=0;i<fields.length;i++){
    fields[i].addEventListener("focus",setBackground);
    fields[i].addEventListener("blur",setBackground);
  }
});

class student{
  constructor(first,last,adress,city,state,zip,email,phone){
    this.first=first;
    this.last=last;
    this.adress=adress;
    this.city=city;
    this.state=state;
    this.zip=zip;
    this.email=email;
    this.phone=phone;
  };

  makeString(){
    var info="First Name: " + this.first+" Last Name: "+this.last+" Adress: "+this.adress+" City: "+this.city+
    " State: "+this.state +" Zip: "+this.zip+" Email: "+this.email+" Phone: "+ this.phone+"$";
    return info;
  };
};

function add(){
  var first=document.getElementById('first').value;
  var last=document.getElementById('last').value;
  var adress=document.getElementById('adress').value;
  var city=document.getElementById('city').value;
  var state=document.getElementById('state').value;
  var zip=document.getElementById('zip').value;
  var email=document.getElementById('email').value;
  var phone=document.getElementById('phone').value;


  let newStudent = new student(first,last,adress,city,state,zip,email,phone);
  clearForm();
  students+=(newStudent.makeString());
  localStorage.clear();
  window.localStorage.setItem("students",students);
  }
